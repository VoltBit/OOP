package hmaps.map;

/**
 *
 * @author Stefan
 */
public interface Value extends Comparable<Value>{
    
    @Override
    public boolean equals(Object other);
}
