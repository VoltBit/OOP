package graphics;

import javax.swing.JFrame;

public class testingGraphics  extends JFrame{

}
