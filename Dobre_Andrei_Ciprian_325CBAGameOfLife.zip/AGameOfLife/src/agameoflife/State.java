package agameoflife;

public enum State {
    Alive,Dead;
}
