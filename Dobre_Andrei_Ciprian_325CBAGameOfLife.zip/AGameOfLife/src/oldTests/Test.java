package oldTests;

public abstract class Test {
    public abstract void run();
}
