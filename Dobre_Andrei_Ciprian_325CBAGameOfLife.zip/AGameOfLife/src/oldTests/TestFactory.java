package oldTests;

public class TestFactory{/*
    public static Test makeLifeRulesTester(){
        Test t = new LifeRulesTest();
        return t;
    }
    public static Test makeLifeSimulationTester(){
        Test t = new LifeSimulationTest();
        return t;
    }
    public static Test makeTableTester(){
        Test t = new JBoardTest();
        return t;
    }*/
}
