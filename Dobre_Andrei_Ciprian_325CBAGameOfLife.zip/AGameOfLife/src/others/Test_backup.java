package others;

public interface Test_backup {
    public void run();
}