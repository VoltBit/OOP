import org.junit.Test;
import static org.junit.Assert.*;

public class LifeBorderlessSimulationTest {

    public LifeBorderlessSimulationTest() {

    }
    
    @Test
    public void getNeighbourTest(){
        
    }
}